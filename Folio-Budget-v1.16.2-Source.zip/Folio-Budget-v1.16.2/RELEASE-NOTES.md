# Folio 1.16.2

- **Search spacing:** the account/transaction search field now uses a shared bordered control with separate icon
  and text columns. The icon is 18px wide, with a fixed 10px gap before the placeholder or entered text and 12px
  outer padding. Both elements stay vertically centered without absolute positioning or an overlaid icon.
  A shared focus ring preserves keyboard visibility, and the text column shrinks on narrow screens.
- **Deployment:** 1.16.2 images; no dependency, schema or migration changes.

# Folio 1.16.1

- **Account search field:** the search-specific padding now takes precedence over the shared input padding,
  reserving space for the icon to the left of both the placeholder and entered text. The icon remains vertically
  centered. This applies to account-filtered and general transaction views.
- **Deployment:** 1.16.1 images; no dependency, schema or migration changes.

# Folio 1.16.0

- **Account transfers:** dedicated Transfer money actions on Transactions, individual account views and Settings.
  Choose two accounts, enter an amount/date and optional notes, and review both balances before confirmation.
  Swap accounts to reverse the direction. One transfer record updates both account balances and remains excluded
  from income and expense totals.
- **Negative balances:** accounts below zero expose Pay negative balance, prefilled with the full current debt,
  including recorded transactions. Choose the paying account and adjust the amount if needed. Opening balances
  and existing payments stay unchanged. Transfers record movements in Folio; bank payments are made separately.
- **Save handling:** duplicate submits are blocked while saving. Failed writes retain the form, and a successful
  write followed by a failed refresh cannot be submitted again from the same dialog.
- **Search alignment:** the Search transactions field explicitly uses a horizontal label layout and vertically
  centers its non-interactive icon on desktop and mobile.
- **Deployment:** 1.16.0 images; no schema, migration or dependency changes. Supplied Dockerfile retained.

# Folio 1.15.4

- **Remaining unconfirmed:** finite schedules show their unpaid, unskipped count (including zero); unlimited schedules
  show **∞** with an accessible spoken label. A defined end date or repetition count keeps the numeric count.
  The table caption and mobile sort choices explain the symbol. Existing count calculations and sorting are retained.
- **Deployment:** 1.15.4 images; no migration or dependency changes. Supplied Dockerfile retained.

# Folio 1.15.3

- **Recurring sorting:** all six data columns sort in both directions, with matching mobile choices and accessible
  sort indicators. Frequency uses cadence order (once, weekly, monthly, yearly), remaining uses numeric order with
  ongoing schedules last in both directions, and status uses alphabetical order with pause taking priority.
  Name and ID break ties consistently. Actions remain management controls rather than a data sort.
- **Overview:** consistent summary-header heights and amount line heights align monetary values across the cards,
  with a matching gap before the balance footer. Reports keep their existing layout.
- **Deployment:** 1.15.3 images; no new dependencies or migrations. Supplied Dockerfile retained.

# Folio 1.15.2

- **Recurring table:** column headers share a centered vertical alignment and stay on a single horizontal line.
- **Remaining unconfirmed:** a new column counts unpaid, unskipped dates across a finite schedule's full ending,
  including overdue dates and paused schedules. Completed schedules show zero; schedules without an ending show
  Ongoing. The count updates after confirmations, skips and schedule edits, including automatic confirmation refreshes.
- **Mobile:** the count appears as another labelled row in the existing responsive table layout.
- **Documentation:** the GitHub README presents current capabilities and links to the detailed operations guide.
- **Deployment:** 1.15.2 images; no schema or dependency changes. Supplied Dockerfile retained.

# Folio 1.15.1

- **Automatic Web Push setup:** backend startup generates and durably stores a private VAPID identity in the existing
  SQLite volume, reusing it across restarts/container replacement. No manual generator or push.env is required.
- **Existing installations:** explicit pairs take precedence and are adopted into persistent storage. Invalid keys,
  damaged files or a missing identity for enrolled devices never cause silent automatic rotation. Only background
  delivery is disabled after a setup failure; budget features remain available.
- **Privacy and delivery:** atomic owner-only files, matching P-256 validation, stable concurrent initialization and
  public-key-only API responses. Existing per-device permission, trusted HTTPS and delivery controls still apply.
- **Deployment:** 1.15.1 images; exact supplied Dockerfile retained. No additional migration or dependency change.

394 tests in forty-eight files pass. See VALIDATION for executed checks and remaining limits.

# Folio 1.15

- **Mobile:** labelled recurring table rows and a compact sort selector keep dates, amounts and actions available.
  Narrow navigation, dialogs, forms, headers and category names receive responsive layouts and touch targets.
- **Automatic confirmation:** opt-in checkbox in Add/Edit recurring and Schedule controls. A backend worker records
  due instances each minute with manual-payment idempotency, even with browsers closed and push disabled. Activation,
  resumption and recurrence changes start eligibility today; earlier overdue dates remain manual. Pauses, skips and
  endings are respected. Missed dates since activation catch up after downtime. The demo runs while open/on reopening.
- **Custom spending categories:** add and select a reusable category directly in the transaction editor. Failed or
  duplicate creation preserves the draft; categories remain available in budgets and reports.
- **Upgrade:** 1.15.0 images and migration 0005 required before backend startup. Existing schedules stay manual;
  imports are paused with automation disabled. Supplied Dockerfile, ports and dependency versions are unchanged.

386 tests in forty-seven files pass. See VALIDATION for executed checks and limits.

# Folio 1.14.1

- **LAN HTTP deletion:** use native SHA-256 when available and a compatible fallback when `crypto.subtle` is absent.
  Exact typed DELETE, explicit acknowledgment, stale-state checks and atomic persistence remain required.
- **Import reviews:** Actual and workspace browser reviews share the fix, retaining unchanged SHA-256 revisions.
- **Paused imports:** Recurring explains why imported schedules start paused and how to resume them. Dates remain
  visible; reminders and Mark paid stay disabled until resumed. The update leaves existing pause choices unchanged.
- **Deployment:** 1.14.1 images; supplied Dockerfile, ports, schema and dependencies unchanged.

372 tests in forty-three files pass. See VALIDATION for executed checks and verification limits.

# Folio 1.14

- **Icon controls:** Edit, Mark paid and Skip use compact icon buttons with accessible names, titles and keyboard
  behavior. Paid/skip actions retain their pause and saving guards across the recurring table/cards and calendar.
- **Counted schedules:** Add/Edit recurring supports Never, On a date or a custom number of repetitions. Counted spans
  start at the displayed due date, include it and retain the original month-end/leap-year anchor. One-time rules allow
  one date. The preview and inclusive final date update before saving.
- **Atomic persistence:** rule and ending save together. Counts preserve pause state/history and do not clear skips
  unless date/frequency changes. Existing finite endings reopen with a count; JSON exports preserve their boundary.
- **Deployment:** 1.14.0 images, exact supplied Dockerfile and ports 8081/5001. Schema/dependencies unchanged.
  Delete-all and overwrite imports from 1.13 remain included.

352 tests in forty-one files pass. See VALIDATION for executed checks and verification limits.

# Folio 1.13

- **Delete all app data:** Settings now offers a count review, explicit acknowledgment and exact typed `DELETE`.
  Cancelling does nothing; stale reviews reject. SQLite deletes financial data, device registrations and reminder
  settings/history atomically. Browser cleanup leaves a blank workspace and preserves unrelated site storage.
- **Overwrite Actual imports:** choose Add (default) or Overwrite. The full replacement review accepts conflicting
  imported identities and requires acknowledgment plus exact typed `REPLACE`. Omitted scope and unsupported schedules
  are removed; all imported schedules stay paused. Folio JSON replacement now also requires typed `REPLACE`.
- **Consistency:** changing source/scope invalidates replacement reviews; source controls lock during writes.
  Late provider replies cannot recreate reminder history after the registered device has been deleted.
- **Deployment:** 1.13.0 images, supplied Dockerfile and ports 8081/5001. No schema/dependency change.

331 tests in thirty-nine files pass. See VALIDATION for executed checks and verification boundaries.

# Folio 1.12

- **Actual due dates:** read source next-date revisions, retain the original recurrence anchor and counted ending,
  and preserve advanced dates as reviewed reversible skips. Recorded payments are never duplicated or rewritten.
  Unchanged older imports can add missing progress without replacing schedules or pause controls.
- **Recurring editor:** editable Due date initialized from the first unconfirmed instance and a live preview of six
  pending dates. Date/frequency changes recalculate the preview; paid/skipped dates and ending limits are respected.
  Unchanged dates preserve anchors; changed recurrence patterns clear prior skips. History remains unchanged.
- **Review and completion:** advanced dates appear before acknowledgment and completion links back to Recurring.
  Actual importer label and registry image tag are 1.12.0. Update frontend and backend together.
- **Deployment:** supplied Dockerfile, ports 8081/5001, schema and dependencies remain unchanged.

313 tests in thirty-seven files pass. See VALIDATION for checks and remaining device/container limits.

# Folio 1.11

- **Calendar instances:** all recurring dates remain visible, orange when unconfirmed, red when overdue and green when
  recorded. Confirmation renders one actual posting. Text labels, a legend, all mobile dots and full-day agendas help
  distinguish states. Open pages refresh their local current date.
- **Paused planning:** paused instances remain visible with confirmation disabled; skips and inclusive endings remain
  respected. Reminder, forecast and posting policies are unchanged.
- **Recurring table:** default sortable table, closest unconfirmed civil date first, overdue dates first on equal
  distance and an overdue count per rule. Name/amount sorting and optional cards retain all management controls.
  Expense labels are red and income labels green.
- **Deployment:** image tag 1.11.0, exact supplied Dockerfile and ports 8081/5001. No schema/dependency change.
  The unchanged Actual decoder retains its independent 1.10.2 label.

300 tests in thirty-six files pass. See VALIDATION for executed checks and verification limits.

# Folio 1.10.2

- **Source review:** supported/total schedules, selected scope, final payment dates and exact historical matches remain
  distinct. The importer version is visible; toggling scope cannot masquerade as an unsupported schedule.
- **Payment warnings:** identify source-linked payments kept on their original dates as ordinary transactions and count
  older imported postings whose null schedule links remain unchanged. Financial values are preserved.
- **Paused preparation:** skip a planned date before resuming a migrated schedule, retaining recorded history. Invalid
  occurrence dates reject and every skip can be restored.
- **Real export verification:** all 15 schedules, 16 postings and six installment endings persist; both balances reconcile
  and repeat/legacy-upgrade checks pass. Private source data stays outside published source and preview seed data.
- **Deployment:** image tag 1.10.2, exact supplied Dockerfile and ports 8081/5001; no schema or dependency change.

284 tests in thirty-four files pass. See VALIDATION for executed checks and verification limits.

# Folio 1.10.1

- **Actual editor defaults:** accept inactive ending fields and ordinary single monthly day patterns instead of rejecting
  standard editor-created schedules. Weekly/yearly rules tolerate inactive monthly patterns; first dates remain faithful.
- **Installments:** convert a supported counted ending into an inclusive final date, retaining paused controls.
- **Useful diagnostics:** exclusions identify exact rule fields; an explicit local download contains failed schedule
  definitions and no transaction history. Visible importer version identifies stale frontend/worker deployments.
- **Deployment:** image tag 1.10.1, unchanged supplied Dockerfile, ports 8081/5001 and no database migration/dependency change.

280 tests pass in thirty-four files, including a real native ZIP with 15 fictional editor-created schedules, exact
counted endings, reopened SQLite persistence, field-specific failures and a no-import diagnostics download.
The user's own source rules were not supplied; importing all of their schedules cannot yet be claimed verified.

# Folio 1.10

- **Compact checkboxes:** native 20-pixel controls no longer inherit text input padding, minimum field heights or
  full-width label rules. Consent and toggle labels retain 44-pixel touch targets; import rows stay horizontal.
- **Actual recurring imports:** exact/approximate/range amounts, approximate date matching, optional payees, account/payee
  aliases, two-account transfer schedules and safe plain category/notes actions. Reviewed estimates disclose source
  values; imported schedules stay paused. Unsupported recurrence/action semantics remain explicit exclusions.
- **Review and upgrade:** each new schedule appears before acknowledgment; completion links to Recurring. Newly supported
  schedules can be added to older imports without changing historical postings. Other edited identities still conflict.
- **Dockerfile:** the supplied file is retained byte-for-byte as Dockerfile; registry Compose defaults to 1.10.0 with
  host ports 8081/5001. No database migration or dependency change.

250 tests pass in thirty-three files. Strict types, zero-warning lint and named-source documentation checks pass.
Browser visuals, Docker/Buildx/ARM64 execution and live push remain unverified. See VALIDATION for build checks.

# Folio 1.9

- **Workspace JSON import:** Settings now supports the self-hosted SQLite application as well as the preview. Review
  every financial collection, download a recovery export and acknowledge a full replacement. Complete graph/file
  validation and a current SHA-256 revision precede the single atomic replacement; late failures roll back all writes.
- **Paused migration:** imported schedules retain end/skip history but start paused. Device subscriptions, notification
  preferences/history and appearance remain intact; old server financial snoozes are cleared. No schema migration.
- **Browser and phone setup:** actual permission and registration status, per-device enrollment/disconnect, user-gesture
  permission timing, actionable HTTPS/iOS Home Screen guidance, copied app address and a current-device test button.
- **Honest delivery feedback:** generic private payloads, provider acceptance rather than claimed display, persistent
  cooldown, expired subscription cleanup and asynchronous foreground mobile display handling.
- **Pi deployment:** versioned registry Compose with host ports 8081/5001 and a file-backed nginx configuration; private
  VAPID-file generator refuses overwrites. Existing Actual Budget import remains available.

224 tests pass in thirty-two files. Production builds, strict types, zero-warning lint and PWA artifacts pass.
Provider delivery is simulated; real devices, Docker/ARM64 execution and HTTPS deployment remain unverified.
See README for import limits, phone requirements, deployment commands and verification limitations.

# Folio 1.8

- **Actual Budget migration:** read a native ZIP locally, confirm EUR, choose scope, review exact additions and all-recorded
  account balances, download the complete review, then acknowledge an additive import.
- **Financial history:** accounts/openings, flat categories, signed postings, split children, paired transfers, clearing
  flags and nonnegative monthly expense allocations. Existing Folio data remains intact.
- **Supported schedules:** simple fixed rules import paused; unsupported schedules and compatibility limits are explicit.
- **Safe repeat imports:** stable source identities prevent duplicates; edited identities and stale reviews block writes.
  SQLite commits are atomic; preview quota failures preserve prior storage. No schema migration is required.
- **Offline decoder:** bounded ZIP/SQLite decoding in a disposable worker; bundled WASM is included in the PWA precache.

189 tests pass in twenty-six files. Lint, strict types, formatting, production builds and PWA worker/WASM checks pass.
Compiled real HTTP checks verify public-demo import, durable reopen, unchanged existing data, repeat detection,
stale-review rejection and graceful shutdown.

See README for mappings, excluded semantics, currency and size limits. See VALIDATION for executed checks and remaining
browser, Docker and live push verification limits.

# Folio 1.7

- **Bulk ledger actions:** select up to 100 visible editable transactions, review exact rows, then recategorize or delete.
  Scope changes clear hidden selection. Reconciled entries are identified and protected on either account leg.
- **Atomic commits:** a current review is required; changed/missing rows, new locks, archived targets and stale metadata
  block the whole batch. SQLite failures roll back all writes and cascades; preview failures preserve stored data.
- **Explicit deletion review:** receipt/import counts, recurring-payment implications, both transfer legs and an
  acknowledgment precede permanent deletion. Category changes retain financial fields, original audit identities and
  supporting links. No new migration or dependency is required.

158 tests pass in twenty-two files. New coverage includes real SQLite rollback and cascades, late locks/stale metadata,
preview review/acknowledgment, failed-write recovery and bounded selection. Production builds, lint, strict types,
formatting and PWA checks pass; compiled real HTTP checks verify the new endpoints and graceful shutdown. Browser,
Docker and live push verification limits remain documented in VALIDATION.

# Folio 1.6

- **Flexible reports:** calendar month, calendar year or inclusive custom dates; exact account/category filters remain
  in report links, including archived historical categories.
- **Consistent comparisons:** previous calendar periods or equal-length custom spans, exact signed changes, and
  percentages only for positive baselines. Summary cards, day/month cash-flow bars, category rows and exports share
  the same scope; previous-only spending categories remain visible.
- **CSV downloads:** a scoped summary/category comparison report plus matching actual income/expense postings.
  Spreadsheet formula protection applies to untrusted labels. Invalid ranges block results and exports.
- **Compatibility:** no new migration or dependency; unavailable bookmarked accounts remain visibly unavailable.

137 tests pass in twenty files, including calendar boundaries, custom civil-day comparisons, exact filters, chart
reconciliation, safe report CSV, restored bookmarks and invalid-range export blocking. Production builds, types, lint,
formatting and PWA artifact checks pass. See VALIDATION for remaining browser, Docker and live push verification limits.

# Folio 1.5

- **Recurring controls:** pause/resume schedules, set inclusive end dates, and skip/restore individual dates. Calendar,
  forecasts, upcoming lists, exports and reminders honor the controls while recorded payments remain intact.
- **Consistent posting:** eligibility is checked atomically with posting; acknowledged retries retain the original
  payment. Reminder scans recheck current control state before each provider send.
- **Backup compatibility:** exports include controls and skips. Legacy backups default to empty collections; changing
  the start/frequency clears skipped exceptions, and deleting a rule cascades its metadata.
- **Build packaging:** clear generated frontend output before the offline precache scan.
- **Preview persistence fixes:** editing actual payments preserves their original audit timestamp and schedule link.
  Manual accounts/schedules stay free of transaction-only fields, and known legacy fields normalize during restore.

116 tests pass, including file-backed controls, paid retries, end dates, skip/restore, worker rechecks, cross-view UI
behavior, backup links and preview audit regressions. See VALIDATION for build evidence and remaining browser, Docker
and live push verification limits. Upgrade self-hosted installations with the reviewed additive migration 0004.

# Folio 1.4

- **Receipts and documents:** attach PNG, JPEG or PDF files to saved transactions; download or remove them. Uploads
  validate byte size, media signature and filename, enforce quotas, and retain retry IDs. Reconciled entries protect
  attachments; deleting a transaction removes its files. SQLite backups include the file bytes.
- **Portable exports:** versioned JSON financial snapshots now include receipts. The server exports a consistent
  SQLite snapshot without notification subscriptions or credentials.
- **Preview recovery:** review and restore a current or legacy JSON export in the device-local preview. Structural and
  relationship checks run before replacement; stale reviews and failed writes preserve current storage. Complete
  server recovery continues through SQLite backups.
- **Safe upgrade:** additive migration 0003 retains the existing financial tables and preview storage key.

103 tests pass, with real file-backed receipt persistence, quotas, statement locks, backup bytes, retry behavior,
preview upload/download/removal, read-only restore review, invalid backups and failed-storage coverage. See VALIDATION
for build checks and the remaining browser, Docker and live push verification limits.

# Folio 1.3

- **Copy a month's budget:** review allocations and rollover settings, fill missing categories or explicitly replace
  matching categories, and preserve destination-only budgets. Archived categories are skipped. The operation does not
  copy spending or carried balances; stale reviews are rejected and SQLite failures roll back the whole batch.
- **Category filtering:** exact category matching combines with account, type and text filters. Archived historical
  categories remain searchable. Account/category scopes stay in the URL; totals and CSV export follow the selection.
- **Archived entry clarity:** retained names show an archived label. Duplicating an archived entry explains how to
  choose an active category before saving, while historical editing can preserve its original category.
- **Compatibility:** no new schema migration or dependencies. Existing databases, preview storage and private audience
  are retained.

87 tests pass, with additional real SQLite rollback/stale-review coverage and browser-local workflow tests. Build,
format, type and lint checks are documented in VALIDATION. Browser visual, Docker and live push checks remain unverified.

# Folio 1.2

- **Monthly budgets:** exact-month limits, explicit zero allocations and optional positive rollover. Allocation, carry
  and actual spending appear separately; the overview uses the same calculation.
- **Savings goals:** targets and dates, signed progress updates, history, monthly pace, editing and reversible archive.
  Retry IDs prevent duplicate progress. Goals track bookkeeping without moving or reserving account funds.
- **Custom categories:** create and archive/restore names in Settings; use them in transactions, budgets and mapped CSV
  imports while preserving historical names and already-created schedules.
- **Faster entry:** recent merchant suggestions respect explicit category/account choices. Duplicate an actual
  transaction into a new entry dated today without changing the original or copying its audit links.
- **Safe upgrade:** additive migration 0002 and backward-compatible preview metadata. Existing v1.1 data is retained.

77 tests pass, including populated-v1.1 upgrade, rollover/year boundaries, goal retry/withdrawal rules, category
validation, and real preview workflows. Type checks, lint and formatting pass. See VALIDATION for build checks and
remaining browser, Docker and live push verification limits. The hosted preview continues to save on this device only.

# Folio 1.1

Folio now helps you look ahead and compare its records against your bank statement.

- **Cash-flow forecasts:** 30/60/90-day account projections, low-balance warnings, optional overdue payments,
  contributing-event details and CSV export. Find them on Overview or the Transactions workflow buttons.
- **Bank CSV import:** local upload, explicit mapping/date/decimal/sign controls, validation, duplicate detection,
  reviewed manual/transfer matches and atomic commits. Imports mark the selected account's rows cleared.
- **Reconciliation:** compare cleared movements against an exact statement balance. Completed statements protect
  their entries; undo the latest statement to correct them. Transfer sides clear independently.
- **Reminder center:** IANA timezone and local delivery time, individual reminders or one daily digest, configurable
  overdue follow-ups, 1-hour/24-hour snoozes and the latest delivery attempts. Open it from the bell or Settings.
- **Compatibility:** an additive SQLite migration preserves v1 balances and schedule links. Existing browser preview
  data remains readable. The development backend command has been corrected.

The private hosted preview still stores its data on the device and delivers notifications only while open.
Background delivery requires the separately hosted Express/SQLite application, VAPID configuration and an opted-in
browser. Provider acknowledgment is not proof that a person has seen a reminder. No real notifications are sent by tests.

Run the setup/upgrade steps in README and read VALIDATION for exact checks and remaining Docker/browser/PWA limits.
